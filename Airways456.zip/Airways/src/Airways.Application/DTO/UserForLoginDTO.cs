﻿namespace Airways.Application.DTO
{
    public class UserForLoginDTO
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
