﻿/*using Airways.Application.Common;
using Airways.Application.Common.Email;
using Airways.Application.Models;
using Airways.Core.Entity;
using Airways.DataAccess.Repository;
using System.Net;
using System.Net.Mail;

namespace Airways.Application.Services.Impl
{
    public class EmailService : IEmailService
    {
        public Task<ApiResult> SendEmailAsync(User user)
        {
            throw new NotImplementedException();
        }
    }
    
*/