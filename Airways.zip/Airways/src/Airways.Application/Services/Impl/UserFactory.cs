﻿namespace Airways.Application.Services.Impl
{
    public class UserFactory { }
}