﻿namespace Airways.Application.Services
{
    public interface IUserFactory { }


}
