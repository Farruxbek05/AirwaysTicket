﻿namespace Airways.Application.Models
{
    public class Option
    {
        public int PageSize { get; set; } = 10;
        public int PageNumber { get; set; } = 1;
    }
}
