﻿namespace Airways.Application.Models.Review
{
    public class ReviewResponceModel
    {
        public int ID { get; set; }
        public int Rating { get; set; }
        public string Comment { get; set; }
    }
}
