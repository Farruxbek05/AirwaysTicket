﻿namespace Airways.Application.Models.Validators
{
    public interface IValidationsMarker { }

}
