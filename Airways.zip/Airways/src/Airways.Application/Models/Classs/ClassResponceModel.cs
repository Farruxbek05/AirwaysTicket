﻿namespace Airways.Application.Models.Classs
{
    public class ClassResponceModel
    {
        public int ID { get; set; }
        public ClassType className { get; set; }
        public string description { get; set; }
    }
}
