﻿using System.ComponentModel.DataAnnotations;

namespace Airways.Application.Models.Order
{
    public class OrderResponceModel
    {
      
        public decimal TotalPrice { get; set; }
    }
}
