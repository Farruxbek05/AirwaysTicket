﻿namespace Airways.Application.Models.Order
{
    public class OrderResponceModel
    {
        public int ID { get; set; }
        public decimal TotalPrice { get; set; }
    }
}
