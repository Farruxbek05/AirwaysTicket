﻿namespace Airways.Application.Models
{
    public class BaseResponceModel
    {
        public Guid Id { get; set; }
    }
}
