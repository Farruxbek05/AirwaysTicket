﻿namespace Airways.Application.MappingProfiles
{
    public interface IMappingProfilesMarker { }
}
