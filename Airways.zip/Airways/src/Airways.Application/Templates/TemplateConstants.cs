﻿namespace Airways.Application.Templates
{
    public static class TemplateConstants
    {
        public const string ConfirmationEmail = "confirmation_email.html";
    }
}
