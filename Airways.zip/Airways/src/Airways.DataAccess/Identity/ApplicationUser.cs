﻿

using Microsoft.AspNetCore.Identity;

namespace Airways.DataAccess.Identity
{
    public class ApplicationUser : IdentityUser { }
}
