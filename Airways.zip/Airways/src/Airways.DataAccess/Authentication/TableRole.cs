﻿namespace Airways.DataAccess.Authentication
{
    public enum TableRole
    {
        Admin,
        User
    }
}
