﻿namespace Airways.DataAccess.Authentication
{
    public static class TableName
    {
        public static string Users = "Users";
        public static string Admins = "Admins";
    }
}
