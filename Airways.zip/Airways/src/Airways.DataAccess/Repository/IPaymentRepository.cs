﻿using Airways.Core.Entity;

namespace Airways.DataAccess.Repository;

    public interface IPaymentRepository : IBaseRepository<Payment> { }
    
