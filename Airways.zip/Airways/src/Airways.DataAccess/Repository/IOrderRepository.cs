﻿using Airways.Core.Entity;

namespace Airways.DataAccess.Repository;

    public interface IOrderRepository : IBaseRepository<Order> { }
    
