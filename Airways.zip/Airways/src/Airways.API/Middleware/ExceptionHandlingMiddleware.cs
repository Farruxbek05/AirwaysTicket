﻿using Airways.Application.Models;

namespace Airways.API.Middleware;

public class ExceptionHandlingMiddleware
{
    
}
