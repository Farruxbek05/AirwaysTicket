﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Airways.Core
{
    public enum RoleTable
    {
        Admin,
        User
    }
}
